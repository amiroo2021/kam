"""Type stubs for bulk_keychain"""

from typing import Any, Literal, TypedDict, NotRequired

SignatureDomain = Literal["mainnet", "testnet", "devnet"]

class OrderTypeLimit(TypedDict):
    type: Literal["limit"]
    tif: NotRequired[Literal["GTC", "IOC", "ALO"]]

class OrderTypeTrigger(TypedDict):
    type: Literal["trigger", "market"]
    is_market: NotRequired[bool]
    trigger_px: NotRequired[float]

OrderType = OrderTypeLimit | OrderTypeTrigger

class BuilderCodeInput(TypedDict):
    to: str
    fee: int

class LiquidatorInstrumentConfig(TypedDict):
    symbol: str
    max_exposure: NotRequired[float]
    reserve: NotRequired[float]
    rfactor: NotRequired[float]
    volume_percent: NotRequired[float]
    volume_min: NotRequired[float]
    volume_rampup: NotRequired[float]
    max_sweep_bps: NotRequired[float]
    max_adl_notional: NotRequired[float]
    max_adl_percent: NotRequired[float]

class LiquidatorConfig(TypedDict):
    cross_exposure: NotRequired[float]
    scoring_skew: NotRequired[float]
    toxicity: NotRequired[float]
    urgency_size_fraction: NotRequired[float]
    sweep_sds: NotRequired[float]
    instruments: NotRequired[list[LiquidatorInstrumentConfig]]

class OrderItem(TypedDict):
    type: Literal["order"]
    symbol: str
    is_buy: bool
    price: float
    size: float
    reduce_only: NotRequired[bool]
    iso: NotRequired[bool]
    builder_code: NotRequired[BuilderCodeInput]
    order_type: NotRequired[OrderType]
    client_id: NotRequired[str]
    on_fill: NotRequired["OnFillInput"]

class OnFillInput(TypedDict):
    actions: list["OrderItemType"]

class CancelItem(TypedDict):
    type: Literal["cancel"]
    symbol: str
    order_id: str

class CancelAllItem(TypedDict):
    type: Literal["cancel_all"]
    symbols: NotRequired[list[str]]

class ModifyItem(TypedDict):
    type: Literal["modify"]
    symbol: str
    order_id: str
    amount: float

OrderItemType = OrderItem | CancelItem | CancelAllItem | ModifyItem
OraclePriceEntry = tuple[int, str, float]      # (timestamp, asset, price)
PythOraclePriceEntry = tuple[int, int, int, int]  # (timestamp, feed_index, price, exponent)

class SignedTransaction(TypedDict):
    actions: list[dict[str, Any]]
    nonce: int
    account: str
    signer: str
    signature: str
    order_id: NotRequired[str]  # Optional pre-computed order ID (single-order tx only)
    order_ids: NotRequired[list[str]]  # Optional pre-computed order IDs (multi-order tx only)

class Keypair:
    """Ed25519 keypair for signing transactions"""

    def __init__(self, key: str | bytes = ..., /) -> None:
        """Generate a new random keypair"""
        ...

    @staticmethod
    def from_base58(s: str) -> "Keypair":
        """Create from base58-encoded secret key or full keypair"""
        ...

    @staticmethod
    def from_bytes(bytes: bytes) -> "Keypair":
        """Create from raw bytes (32-byte secret or 64-byte keypair)"""
        ...

    @property
    def pubkey(self) -> str:
        """Get the public key as base58 string"""
        ...

    def to_base58(self) -> str:
        """Get the full keypair as base58 (64 bytes)"""
        ...

    def to_bytes(self) -> bytes:
        """Get the full keypair as bytes (64 bytes)"""
        ...

    def secret_key(self) -> bytes:
        """Get the secret key as bytes (32 bytes)"""
        ...

class Signer:
    """High-performance transaction signer"""

    def __init__(self, keypair: Keypair, signature_domain: SignatureDomain) -> None:
        """Create a new signer from a keypair"""
        ...

    @staticmethod
    def from_base58(s: str, signature_domain: SignatureDomain) -> "Signer":
        """Create a signer from base58-encoded secret key"""
        ...

    @staticmethod
    def with_nonce_manager(
        keypair: Keypair,
        strategy: Literal["timestamp", "counter", "high_frequency"],
        signature_domain: SignatureDomain,
    ) -> "Signer":
        """Create a signer with nonce management"""
        ...

    @property
    def pubkey(self) -> str:
        """Get the signer's public key"""
        ...

    def set_compute_order_id(self, enabled: bool) -> None:
        """Enable/disable single-order ID computation"""
        ...

    def set_compute_batch_order_ids(self, enabled: bool) -> None:
        """Enable/disable batch order ID computation for multi-order transactions"""
        ...

    def computes_order_id(self) -> bool:
        """Whether single-order ID computation is enabled"""
        ...

    def computes_batch_order_ids(self) -> bool:
        """Whether batch order ID computation is enabled"""
        ...

    def sign_bytes(self, message: bytes) -> str:
        """Sign raw message bytes and return a base58 Ed25519 signature"""
        ...

    def sign_wallet_prepared(self, wallet: WalletPreparedMessage) -> SignedTransaction:
        """Sign the selected wallet mode, enforcing configured key and network."""
        ...

    def sign_prepared(self, prepared: "PreparedMessage") -> SignedTransaction:
        """Sign a prepared message and finalize it into a signed transaction.

        Supports agent-wallet flows where prepared["account"] is the trading
        account and prepared["signer"] is this signer's pubkey. Raises
        ValueError if prepared["signer"] does not match this signer's pubkey.
        """
        ...

    # ========================================================================
    # Simplified API
    # ========================================================================

    def sign(
        self,
        order: OrderItemType,
        nonce: int | None = None
    ) -> SignedTransaction:
        """Sign a single order/cancel/cancelAll - returns single transaction"""
        ...

    def sign_all(
        self,
        orders: list[OrderItemType],
        base_nonce: int | None = None
    ) -> list[SignedTransaction]:
        """Sign multiple orders - each becomes its own transaction (parallel)
        
        Optimized for HFT: each order gets independent confirmation/rejection.
        """
        ...

    def sign_group(
        self,
        orders: list[OrderItemType],
        nonce: int | None = None
    ) -> SignedTransaction:
        """Sign multiple orders atomically in ONE transaction
        
        Use for bracket orders (entry + stop loss + take profit).
        """
        ...

    # ========================================================================
    # Other signing methods
    # ========================================================================

    def sign_faucet(self, nonce: int | None = None) -> SignedTransaction:
        """Sign a faucet request (testnet only)"""
        ...

    def sign_agent_wallet(
        self,
        agent_pubkey: str,
        delete: bool,
        nonce: int | None = None
    ) -> SignedTransaction:
        """Sign agent wallet creation/deletion"""
        ...

    def sign_update_liquidator_config(
        self,
        config: LiquidatorConfig,
        nonce: int | None = None
    ) -> SignedTransaction:
        """Sign a liquidator config update (`liq`)"""
        ...

    def sign_approve_commission_fee(
        self,
        to_pubkey: str,
        fee: int,
        nonce: int | None = None
    ) -> SignedTransaction:
        """Sign builder-code recipient approval (`abc`)"""
        ...

    def sign_approve_builder_code(
        self,
        to_pubkey: str,
        fee: int,
        nonce: int | None = None
    ) -> SignedTransaction:
        """Sign builder-code recipient approval (`abc`)"""
        ...

    def sign_revoke_commission_fee(
        self,
        to_pubkey: str,
        nonce: int | None = None
    ) -> SignedTransaction:
        """Sign builder-code recipient revocation (`rbc`)"""
        ...

    def sign_revoke_builder_code(
        self,
        to_pubkey: str,
        nonce: int | None = None
    ) -> SignedTransaction:
        """Sign builder-code recipient revocation (`rbc`)"""
        ...

    def sign_user_settings(
        self,
        max_leverage: list[tuple[str, float]],
        nonce: int | None = None
    ) -> SignedTransaction:
        """Sign user settings update"""
        ...

    def sign_oracle_prices(
        self,
        oracles: list[OraclePriceEntry],
        nonce: int | None = None
    ) -> SignedTransaction:
        """Sign one or more oracle price updates (`px`)"""
        ...

    def sign_pyth_oracle(
        self,
        oracles: list[PythOraclePriceEntry],
        nonce: int | None = None
    ) -> SignedTransaction:
        """Sign a batch Pyth oracle update (`o`)"""
        ...

    def sign_whitelist_faucet(
        self,
        target_pubkey: str,
        whitelist: bool,
        nonce: int | None = None
    ) -> SignedTransaction:
        """Sign whitelist/un-whitelist faucet access (`whitelistFaucet`)"""
        ...

    def sign_create_sub_account(
        self,
        name: str,
        margin_amount: float | None = None,
        nonce: int | None = None
    ) -> SignedTransaction:
        """Sign a sub-account creation (optional initial margin transfer)"""
        ...

    def sign_transfer(
        self,
        from_pubkey: str,
        to_pubkey: str,
        margin_amount: float,
        kind: str | None = None,
        nonce: int | None = None
    ) -> SignedTransaction:
        """Sign a margin transfer between accounts (kind: "internal" or "external")"""
        ...

    def sign_remove_sub_account(
        self,
        to_remove: str,
        nonce: int | None = None
    ) -> SignedTransaction:
        """Sign a sub-account removal"""
        ...

    # ========================================================================
    # Legacy methods (deprecated)
    # ========================================================================

    def sign_order(
        self,
        orders: list[OrderItemType],
        nonce: int | None = None
    ) -> SignedTransaction:
        """Deprecated: Use sign(), sign_all(), or sign_group() instead"""
        ...

    def sign_orders_batch(
        self,
        batches: list[list[OrderItemType]],
        base_nonce: int | None = None
    ) -> list[SignedTransaction]:
        """Deprecated: Use sign_all() instead"""
        ...

def random_hash() -> str:
    """Generate a random hash (for client order IDs)"""
    ...

def current_timestamp() -> int:
    """Get the current Unix timestamp in nanoseconds"""
    ...

def validate_pubkey(s: str) -> bool:
    """Validate a base58-encoded public key"""
    ...

def validate_hash(s: str) -> bool:
    """Validate a base58-encoded hash"""
    ...

def compute_order_id(wincode_bytes: bytes) -> str:
    """Compute SHA256 hash from raw bytes.
    
    This is a raw utility and does not apply BULK order-ID canonicalization.
    """
    ...

def compute_order_id_from_order(
    order: OrderItemType | dict[str, Any],
    nonce: int,
    account: str,
) -> str | None:
    """Compute order ID from order JSON without a private key.

    Supports simplified order objects (`{"type": "order", ...}`) and compact
    API order objects (`{"l": {...}}` / `{"m": {...}}`).

    Returns None for non-order actions.
    """
    ...

# ============================================================================
# External Wallet Support - Prepare/Finalize API
# ============================================================================

class PreparedMessage(TypedDict):
    """Message prepared for external wallet signing"""
    message_bytes: bytes      # Raw bytes to pass to wallet.signMessage()
    message_base58: str       # Base58 encoded message
    message_base64: str       # Base64 encoded message
    message_hex: str          # Hex encoded message
    order_id: NotRequired[str]  # Optional pre-computed order ID
    order_ids: NotRequired[list[str]]  # Optional pre-computed order IDs for multi-order tx
    actions: list[dict[str, Any]]  # Compact tagged actions for API
    account: str              # Account public key (base58)
    signer: str               # Signer public key (base58)
    nonce: int                # Nonce used

def prepare_order(
    order: OrderItemType,
    signature_domain: SignatureDomain,
    account: str,
    signer: str | None = None,
    nonce: int | None = None
) -> PreparedMessage:
    """Prepare a single order for external wallet signing
    
    Use this when you don't have access to the private key and need
    to sign with an external wallet.
    
    Example:
        prepared = prepare_order(order, "account_pubkey")
        signature = wallet.sign_message(prepared["message_bytes"])
        signed = finalize_transaction(prepared, signature)
    """
    ...

def prepare_all_orders(
    orders: list[OrderItemType],
    signature_domain: SignatureDomain,
    account: str,
    signer: str | None = None,
    base_nonce: int | None = None
) -> list[PreparedMessage]:
    """Prepare multiple orders - each becomes its own transaction (parallel)"""
    ...

def prepare_order_group(
    orders: list[OrderItemType],
    signature_domain: SignatureDomain,
    account: str,
    signer: str | None = None,
    nonce: int | None = None
) -> PreparedMessage:
    """Prepare multiple orders as ONE atomic transaction
    
    Use for bracket orders (entry + stop loss + take profit).
    """
    ...

def prepare_agent_wallet(
    agent_pubkey: str,
    delete: bool,
    signature_domain: SignatureDomain,
    account: str,
    signer: str | None = None,
    nonce: int | None = None
) -> PreparedMessage:
    """Prepare agent wallet creation for external signing"""
    ...

def prepare_update_liquidator_config(
    config: LiquidatorConfig,
    signature_domain: SignatureDomain,
    account: str,
    signer: str | None = None,
    nonce: int | None = None
) -> PreparedMessage:
    """Prepare a liquidator config update (`liq`) for external signing"""
    ...

def prepare_approve_commission_fee(
    to_pubkey: str,
    fee: int,
    signature_domain: SignatureDomain,
    account: str,
    signer: str | None = None,
    nonce: int | None = None
) -> PreparedMessage:
    """Prepare builder-code recipient approval for external signing"""
    ...

def prepare_approve_builder_code(
    to_pubkey: str,
    fee: int,
    signature_domain: SignatureDomain,
    account: str,
    signer: str | None = None,
    nonce: int | None = None
) -> PreparedMessage:
    """Prepare builder-code recipient approval for external signing"""
    ...

def prepare_revoke_commission_fee(
    to_pubkey: str,
    signature_domain: SignatureDomain,
    account: str,
    signer: str | None = None,
    nonce: int | None = None
) -> PreparedMessage:
    """Prepare builder-code recipient revocation for external signing"""
    ...

def prepare_revoke_builder_code(
    to_pubkey: str,
    signature_domain: SignatureDomain,
    account: str,
    signer: str | None = None,
    nonce: int | None = None
) -> PreparedMessage:
    """Prepare builder-code recipient revocation for external signing"""
    ...

def prepare_faucet(
    signature_domain: SignatureDomain,
    account: str,
    signer: str | None = None,
    nonce: int | None = None
) -> PreparedMessage:
    """Prepare faucet request for external signing"""
    ...

def prepare_create_sub_account(
    name: str,
    signature_domain: SignatureDomain,
    account: str,
    margin_amount: float | None = None,
    signer: str | None = None,
    nonce: int | None = None
) -> PreparedMessage:
    """Prepare a sub-account creation for external signing"""
    ...

def prepare_transfer(
    from_pubkey: str,
    to_pubkey: str,
    margin_amount: float,
    signature_domain: SignatureDomain,
    account: str,
    kind: str | None = None,
    signer: str | None = None,
    nonce: int | None = None
) -> PreparedMessage:
    """Prepare a margin transfer for external signing (kind: "internal" or "external")"""
    ...

def prepare_remove_sub_account(
    to_remove: str,
    signature_domain: SignatureDomain,
    account: str,
    signer: str | None = None,
    nonce: int | None = None
) -> PreparedMessage:
    """Prepare a sub-account removal for external signing"""
    ...

def finalize_transaction(
    prepared: PreparedMessage,
    signature: str
) -> SignedTransaction:
    """Verify signature and account/nonce metadata, then finalize.

    Raises ValueError for invalid signatures or metadata. Actions and order IDs
    must remain original trusted prepare output; action JSON is not rederived.

    Args:
        prepared: PreparedMessage dict from prepare_* functions
        signature: Base58-encoded signature from wallet
    
    Returns:
        SignedTransaction dict ready for API submission
    """
    ...

class SolanaAccountMeta(TypedDict):
    pubkey: str
    is_signer: bool
    is_writable: bool

class SolanaInstruction(TypedDict):
    program_id: str
    accounts: list[SolanaAccountMeta]
    data: bytes

def build_deposit_instruction(owner: str, amount: int) -> SolanaInstruction:
    """Build a mainnet USDC deposit instruction; amount is u64 base units."""
    ...

def build_withdraw_intent_instruction(owner: str, amount: int) -> SolanaInstruction:
    """Build a mainnet USDC withdrawal intent; this instruction transfers no tokens."""
    ...

def export_deposit_transaction(owner: str, amount: int, recent_blockhash: str) -> str:
    """Export base64 unsigned mainnet USDC deposit transaction; amount is base units."""
    ...

def export_withdraw_intent_transaction(owner: str, amount: int, recent_blockhash: str) -> str:
    """Export base64 unsigned mainnet USDC withdrawal-intent transaction."""
    ...

class WalletPreparedMessage(TypedDict):
    prepared: PreparedMessage
    signature_mode: Literal["raw", "base58", "offchain"]
    message_bytes: bytes
    clear_sign_message: str | None

def prepare_wallet_message(prepared: PreparedMessage, mode: Literal["raw", "base58", "offchain"]) -> WalletPreparedMessage:
    ...

def finalize_wallet_message(wallet: WalletPreparedMessage, signature: str) -> SignedTransaction:
    ...

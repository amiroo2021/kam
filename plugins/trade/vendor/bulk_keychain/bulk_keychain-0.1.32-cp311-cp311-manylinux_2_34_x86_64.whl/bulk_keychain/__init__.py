"""
bulk-keychain: A simple high perf signing lib for BULK txns

This package provides fast, native transaction signing using Rust bindings.

Quick Start
-----------
>>> from bulk_keychain import Keypair, Signer
>>>
>>> # Generate a keypair
>>> keypair = Keypair()
>>> print(keypair.pubkey)
>>>
>>> # Create a signer
>>> signer = Signer(keypair, "devnet")
>>>
>>> # Sign a single order
>>> signed = signer.sign({
...     "type": "order",
...     "symbol": "BTC-USD",
...     "is_buy": True,
...     "price": 100000.0,
...     "size": 0.1,
...     "order_type": {"type": "limit", "tif": "GTC"}
... })
"""

from bulk_keychain._native import (
    prepare_wallet_message,
    finalize_wallet_message,
    export_deposit_transaction,
    export_withdraw_intent_transaction,
    build_deposit_instruction,
    build_withdraw_intent_instruction,
    Keypair,
    Signer,
    random_hash,
    current_timestamp,
    validate_pubkey,
    validate_hash,
    compute_order_id,
    compute_order_id_from_order,
    # External wallet support
    py_prepare_order as prepare_order,
    py_prepare_all_orders as prepare_all_orders,
    py_prepare_order_group as prepare_order_group,
    py_prepare_agent_wallet_auth as prepare_agent_wallet,
    py_prepare_update_liquidator_config as prepare_update_liquidator_config,
    py_prepare_approve_builder_code as prepare_approve_builder_code,
    py_prepare_approve_commission_fee as prepare_approve_commission_fee,
    py_prepare_revoke_builder_code as prepare_revoke_builder_code,
    py_prepare_revoke_commission_fee as prepare_revoke_commission_fee,
    py_prepare_faucet_request as prepare_faucet,
    py_prepare_create_sub_account as prepare_create_sub_account,
    py_prepare_remove_sub_account as prepare_remove_sub_account,
    py_prepare_transfer as prepare_transfer,
    py_finalize_transaction as finalize_transaction,
)

__all__ = [
    "prepare_wallet_message",
    "finalize_wallet_message",
    "export_deposit_transaction",
    "export_withdraw_intent_transaction",
    "build_deposit_instruction",
    "build_withdraw_intent_instruction",
    "Keypair",
    "Signer",
    "random_hash",
    "current_timestamp",
    "validate_pubkey",
    "validate_hash",
    "compute_order_id",
    "compute_order_id_from_order",
    # External wallet support
    "prepare_order",
    "prepare_all_orders",
    "prepare_order_group",
    "prepare_agent_wallet",
    "prepare_update_liquidator_config",
    "prepare_approve_builder_code",
    "prepare_approve_commission_fee",
    "prepare_revoke_builder_code",
    "prepare_revoke_commission_fee",
    "prepare_faucet",
    "prepare_create_sub_account",
    "prepare_remove_sub_account",
    "prepare_transfer",
    "finalize_transaction",
]

__version__ = "0.1.32"
